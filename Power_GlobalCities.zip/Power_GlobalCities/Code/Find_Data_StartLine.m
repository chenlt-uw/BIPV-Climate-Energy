%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This code is to find data starting line of the actual weather data table% 
% from TMY excel weather file.                                            %
% Author: Liutao Chen (chenlt@ust.hk)                                     %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function data_start_line = Find_Data_StartLine(filename)
    fid = fopen(filename, 'r');
    if fid == -1
        error('Cannot open file: %s', filename);
    end
    
    data_start_line = 0;
    line_count = 0;
    
    try
        while ~feof(fid)
            line = fgetl(fid);
            line_count = line_count + 1;
            
            if contains(line, 'Date') && contains(line, 'HH:MM')
                data_start_line = line_count;
                break;
            end
        end
    catch ME
        fclose(fid);
        rethrow(ME);
    end
    
    fclose(fid);
    
    if data_start_line == 0
        error('Failed to locate weather data starting point');
    end
end

