%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Calculate_Zenith_Azimuth_incidence                                            % 
% This program calculates the solar zenith and azimuth angle,                    % 
% and incident angle on vertical facade for each day.                            % 
%                                                                                % 
% References:                                                                    %  
% [1] https://www.sciencedirect.com/topics/engineering/solar-incidence-angle     % 
% [2] https://www.esrl.noaa.gov/gmd/grad/solcalc/solareqns.PDF                   % 
% [3] https://journals.ametsoc.org/view/journals/apme/50/9/2011jamc2665.1.xml    %
% [4] Ref: https://www.sciencedirect.com/topics/engineering/solar-incidence-angle%
% Author: Liutao Chen (chenlt@ust.hk)                                            % 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [zenith,azimuth,incd]= ...
    Calculate_Zenith_Azimuth_Incidence(Lat, Lon, Azs, iday, TimeZone)

    % Input parameters: 
    % Lat - Latitude in degrees (negative for southern hemisphere)
    % Lon - Longitude in degress (negative for western hemisphere)
    % Azs - Surface azimuth angle in degrees (west positive, south=0)
    % iday - Day of year (1-365, Jan 1 = 1)
    % TimeZone - Time zone offset from UTC in hours (e.g., -5 for EST)

    % OUTPUT PARAMETERS:
    % zenith   - Solar zenith angle in radians (0�� at zenith, 90�� at horizon)
    % azimuth  - Solar azimuth angle in radians (0�� at north, clockwise)
    % incd     - Incident angle on surface in radians (0�� normal)

    %% INITIALIZATION AND UNIT CONVERSION
    % Surface configuration: vertical facade (90�� tilt from horizontal)
    Slope = 90;     % Tilt angle: 90�� = vertical, 0�� = horizontal
    
    % Convert all angles from degrees to radians for trigonometric operations
    Azs_rad = Azs * pi / 180;        % Surface azimuth angle [rad]
    Slope_rad = Slope * pi / 180;    % Surface tilt angle [rad]  
    Lat_rad = Lat * pi / 180;        % Latitude [rad]

    % Time vectors for 24-hour calculation
    doy = iday.*ones(1,24);         % Day of year repeated for each hour
    hour = linspace(0, 24, 24);     % Hour of day (0 to 24)
    
    %% SOLAR DECLINATION AND EQUATION OF TIME
    % Calculate fractional year in radians for seasonal variations
    y = (2*pi/365).*(doy - 1 + (hour - 12)/24);
    
    % From y, we can estimate the equation of time (in minutes) and the solar declination angle (in radians).
    % The solar declination angle is the angular distance of the sun��s rays north (or south) of the equator,
    % north declination designated as positive.
    eqtime = 229.18*(0.000075 + 0.001868*cos(y) - 0.032077*sin(y) - 0.014615*cos(2*y) - 0.040849*sin(2*y));
    declin_rad = 0.006918 - 0.399912*cos(y) + 0.070257*sin(y) - 0.006758*cos(2*y) ...
        + 0.000907*sin(2*y) - 0.002697*cos(3*y) + 0.00148*sin(3*y);
    
    %% SOLAR TIME AND HOUR ANGLE CALCULATION
    % Next, the true solar time is calculated in the following two equations.
    % First the time offset is found, in minutes, and then the true solar time, in minutes.
    time_offset = eqtime + 4*(Lon) - 60*TimeZone;
    % True solar time (minutes) - actual sun position-based time
    tst = hour*60 + time_offset;   
    
    % Solar hour angle (degrees) - sun's position east/west of local meridian
    % Negative: morning, Zero: solar noon, Positive: afternoon          
    ha = tst/4 - 180;
    ha_rad = ha.*pi/180;

    %% SOLAR ZENITH ANGLE CALCULATION
    % Zenith angle: angle between sun direction and vertical (0�� = overhead)
    % Based on spherical trigonometry formula using latitude, declination, and hour angle
    zenith = acos(sin(Lat_rad).*sin(declin_rad) + cos(Lat_rad).*cos(declin_rad).*cos(ha_rad));
    % Set zenith to 90�� when sun is below horizon (no direct radiation)
    zenith( zenith >= pi/2. ) = pi/2.;
    zenith = zenith(:);


    %% SOLAR AZIMUTH ANGLE CALCULATION
    % Azimuth angle: compass direction of sun (0�� = North, 90�� = East, 180�� = South)
    % Using stable atan2 formulation to avoid division by zero issues
    % https://www.sciencedirect.com/topics/engineering/solar-azimuth-angle
    % https://journals.ametsoc.org/view/journals/apme/50/9/2011jamc2665.1.xml
    numerator = -sin(ha_rad);  
    denominator = cos(Lat_rad)*tan(declin_rad) - sin(Lat_rad)*cos(ha_rad);
    azimuth = atan2(numerator, denominator); 
    azimuth = mod(azimuth + 2*pi, 2*pi);  % Convert to [0, 2��] range
    azimuth = azimuth(:);
    

    %% INCIDENT ANGLE CALCULATION ON VERTICAL SURFACE
    % Azs = surface azimuth angle (unit: derees), the angle between the normal to the surface from true south,
    % westward is designated as positive, zero for south orientation
    % Incident angle: angle between sun rays and surface normal
    % Comprehensive formula accounts for surface orientation and sun position
    % Ref: https://www.sciencedirect.com/topics/engineering/solar-incidence-angle
    cosincd = sin(Lat_rad).*sin(declin_rad).*cos(Slope_rad) - ...
        cos(Lat_rad).*sin(declin_rad).*sin(Slope_rad).*cos(Azs_rad) + ...
        cos(Lat_rad).*cos(declin_rad).*cos(ha_rad).*cos(Slope_rad) + ...
        sin(Lat_rad).*cos(declin_rad).*cos(ha_rad).*sin(Slope_rad).*cos(Azs_rad) + ...
        cos(declin_rad).*sin(ha_rad).*sin(Slope_rad).*sin(Azs_rad);
    incd = acos(cosincd);        % Incident angle from cosine value
    incd(incd >= pi/2) = pi/2;   % Set to 90�� when no direct radiation (below horizon)
    incd = incd(:);

end



