%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This code is to find radiation data from TMY weather data table.        % 
% Author: Liutao Chen (chenlt@ust.hk)                                     %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [SW_data, column_info] = Extract_Radiation_Data(weather_data)

    % Find radiation columns with exact matching
    var_names = weather_data.Properties.VariableNames;
    
    direct_normal_idx = find(contains(var_names, 'DirNormRad'), 1);
    diffuse_horizontal_idx = find(contains(var_names, 'DifHorzRad'), 1);

    % Fallback: try case-insensitive search if exact match fails
    if isempty(direct_normal_idx)
        direct_normal_idx = find(contains(lower(var_names), lower('Direct')), 1);
    end
    if isempty(diffuse_horizontal_idx)
        diffuse_horizontal_idx = find(contains(lower(var_names), lower('Diffuse')), 1);
    end
    
    % Validation
    if isempty(direct_normal_idx)
        error('Direct normal radiation column not found');
    end
    if isempty(diffuse_horizontal_idx)
        error('Diffuse horizontal radiation column not found');
    end
    
    % Extract data
    SW_data = [weather_data{:, direct_normal_idx}, ...
               weather_data{:, diffuse_horizontal_idx}];
    
    % Return column information
    column_info.direct_name = var_names{direct_normal_idx};
    column_info.diffuse_name = var_names{diffuse_horizontal_idx};
    column_info.direct_idx = direct_normal_idx;
    column_info.diffuse_idx = diffuse_horizontal_idx;
end