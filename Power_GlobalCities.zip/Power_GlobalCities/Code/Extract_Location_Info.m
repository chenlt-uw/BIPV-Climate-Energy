%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This code is to extract latitude, longitude, and time zone information  %
% from TMY excel weather file.                                            %
% Latitude {N+/S-}	Longitude {E+/W-}	TimeZone {+/- GMT}                %
% Author: Liutao Chen (chenlt@ust.hk)                                     %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Lat, Lon, TimeZone] = Extract_Location_Info(filename)
    % Read the first two lines to get metadata
    fid = fopen(filename, 'r');
    if fid == -1
        error('Cannot open file: %s', filename);
    end
    
    header_line1 = fgetl(fid);
    header_line2 = fgetl(fid);
    fclose(fid);
    
    % Parse location data
    header_data = strsplit(header_line2, ',');
    
    % Extract latitude and longitude with validation
    if length(header_data) >= 4
        Lat = str2double(header_data{2});
        Lon = str2double(header_data{3});
        TimeZone = str2double(header_data{4});
        
        % Validate coordinates
        if isnan(Lat) || isnan(Lon) || Lat < -90 || Lat > 90 || Lon < -180 || Lon > 180
            error('Invalid coordinates: Latitude=%.4f, Longitude=%.4f', Lat, Lon);
        end
    else
        error('Insufficient location data in metadata');
    end
end