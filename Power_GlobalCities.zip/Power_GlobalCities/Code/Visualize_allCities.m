%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% POWER GENERATION ANALYSIS AND VISUALIZATION TOOL                        %
%                                                                         %
% This script processes hourly solar power generation data from multiple  %
% cities, calculates monthly total energy production for different        %
% orientations, and generates comparative heatmap visualizations.         %
%                                                                         %
% KEY FEATURES:                                                           %
% - Reads multiple CSV files with power generation data                   %
% - Processes 8760 hourly data points for each city                       %
% - Calculates monthly energy sums for 8 cardinal directions              %
% - Generates heatmap visualizations                                      %
% - Supports customizable color schemes and formatting                    %
%                                                                         %
% INPUT: directory is '../Power_Output/'. CSV files with columns          %
% for DateTime and 8 orientations (S, SW, W, NW, N, NE, E, SE)            %
%                                                                         %
% OUTPUT: directory is '../Power_Month_HeatMap/'                          %
% Monthly energy heatmaps and structured results.                         %
%                                                                         %
%                                                                         %
% Author: Liutao Chen (chenlt@ust.hk; chenlt@uw.edu)                      %
%                                                                         %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear


%% ==== 0. CREATE OUTPUT DIRECTORY FOR HEATMAPS ===========================
Fig_output_dir = '../Power_Month_HeatMap/';
if ~exist(Fig_output_dir, 'dir')
    mkdir(Fig_output_dir);
    fprintf('Created output directory: %s\n', Fig_output_dir);
end


%% ==== 1. READ ALL CSV FILES FROM POWER_OUTPUT DIRECTORY =================
Annual_power_dir = '../Power_Output/';
csv_files = dir(fullfile(Annual_power_dir, '*_Power.csv'));

% Create structure to store monthly power results
monthly_power_results = struct();


%% ==== 2. PROCESS EACH CSV FILE ==========================================
for file_idx = 1 : length(csv_files)

    % Read CSV file
    filename = fullfile(Annual_power_dir, csv_files(file_idx).name);
    Power_year = readtable(filename);

    % Extract city name from filename and format it
    city_name = strrep(csv_files(file_idx).name, '_Power.csv', '');
    city_name = strrep(city_name, ' ', '_');  % Replace spaces with underscores


    %% ==== 3. PROCESS DATETIME COLUMN AND EXTRACT MONTH INFORMATION ======
    if ismember('DateTime_Power_Wh_m_2_', Power_year.Properties.VariableNames)
        datetime_col = 'DateTime_Power_Wh_m_2_';
    else
        % Use first column as datetime if standard name not found
        datetime_col = Power_year.Properties.VariableNames{1};
    end

    % Convert to datetime format
    Power_year.DateTime = datetime(Power_year.(datetime_col));

    % Extract month information (1-12)
    Power_year.Month = month(Power_year.DateTime);


    %% ==== 4. DEFINE EIGHT CARDINAL DIRECTIONS ===========================
    directions = {'South', 'Southwest', 'West', 'Northwest', 'North', 'Northeast', 'East', 'Southeast'};

    % Check which direction columns actually exist in the data
    available_directions = {};
    for i = 1:length(directions)
        if ismember(directions{i}, Power_year.Properties.VariableNames)
            available_directions{end+1} = directions{i};
        end
    end


    %% ==== 5. CALCULATE TOTAL POWER GENERATION ===========================
    % Initialize monthly power matrix (12 months × number of available directions)
    monthly_power = zeros(12, length(available_directions));

    % Calculate total power generation for each month and direction
    for month_idx = 1:12
        month_data = Power_year(Power_year.Month == month_idx, :);

        for dir_idx = 1:length(available_directions)
            dir_name = available_directions{dir_idx};
            monthly_power(month_idx, dir_idx) = sum(month_data.(dir_name));
        end
    end

    % Convert from Watt-hours to kiloWatt-hours (kWh)
    monthly_power_kWh = monthly_power / 1000;

    % Store results in structure
    monthly_power_results.(city_name) = struct();
    monthly_power_results.(city_name).monthly_power = monthly_power_kWh;
    monthly_power_results.(city_name).directions = available_directions;


    %% ==== 6. CREATE HEATMAP VISUALIZATION ===============================
    figure
    ha = tight_subplot(1, 1, [.08 0.1], [0.12 0.14], [0.1 0.03]);
    axes(ha(1));

    % Generate heatmap
    h = heatmap(monthly_power_kWh);

    % Set axis labels with abbreviated orientation names
    Ori_names = {'S', 'SW', 'W', 'NW', 'N', 'NE', 'E', 'SE'};  % Abbreviated directions
    h.XDisplayLabels = Ori_names;
    % month_names = {'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'};
    month_names = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'};
    h.YDisplayLabels = month_names;

    % Make grid lines visible (if not already)
    h.GridVisible = 'off';
 
    % Set font properties
    set(gca, 'FontName','Arial', 'fontsize', 10)


    % Create a custom title above the heatmap, or % h.Title = city_name;
    city_name = strrep(city_name, '_', ' ');  % Replace underscores with spaces  
    disp(city_name) 
    annotation('textbox', [0.1, 0.9, 0.8, 0.05], ...
        'String', city_name, ...
        'FontName', 'Arial', ...
        'FontSize', 16, ...
        'FontWeight', 'bold', ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'LineStyle', 'none', ...
        'FitBoxToText', 'on');

    % Set color scale limits (0-6 kWh)
    h.ColorLimits = [0 6];
    h.ColorbarVisible = 'on';    % Hide colorbar
  
    % h.FontColor = [0 0 0];  % Set font color to black
    h.CellLabelColor = 'none';  % Hide cell values (remove numerical display)

    % Set font properties
    % h.XLabel = 'Orientation';
    % h.YLabel = 'Month';

    % Prevent x-axis label rotation
    h.XDisplayData = h.XDisplayData;  % This prevents automatic rotation

    % Apply color scheme (using parula as fallback if TheColor function not available)
    try
        Color = TheColor('Gradient', 947, 'Map', 24);
        colormap(Color);
    catch
        colormap(parula);  % Fallback to default colormap
        warning('TheColor function not available, using parula colormap');
    end

    % Format cell value display (1 decimal place)
    h.CellLabelFormat = '%.1f';

    % Adjust figure size
    figureUnits = 'centimeters';
    figureWidth = 18.3*0.4;
    figureHeight = 24.7*0.2;
    set(gcf, 'Units', figureUnits, 'Position', [0 0 figureWidth figureHeight]);


    %% ==== 7. SAVE FIGURE TO OUTPUT DIRECTORY ============================
    % Create output filename
    output_filename = fullfile(Fig_output_dir, sprintf('%s_monthly_power.png', city_name));
    
    % Save figure as high-resolution PNG
    print(gcf, output_filename, '-r600', '-djpeg');
    fprintf('Saved heatmap for %s: %s\n', city_name, output_filename);

    % Close figure to avoid memory issues when processing many files
    close(gcf);

end

%% ==== 8. DISPLAY PROCESSING COMPLETION MESSAGE ==========================
fprintf('Processing completed. %d files analyzed successfully.\n', length(csv_files));


%% ==== 9. SAVE SUMMARY DATA TO EXCEL FILE ================================
% Create Excel filename
Excel_filename = fullfile(Fig_output_dir, 'Monthly_power_summary.xlsx');

% Save results to Excel (each city in separate sheet)
cities = fieldnames(monthly_power_results);
for i = 1:length(cities)
    city = cities{i};
    data = monthly_power_results.(city).monthly_power;
    directions = monthly_power_results.(city).directions;
    
    % Create table with proper row and column names
    T = array2table(data, ...
        'VariableNames', directions, ...
        'RowNames', {'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'});
        
    % Format data to 4 decimal places
    for col = 1:width(T)
        T.(col) = round(T.(col), 4);
    end
    
    % Calculate annual sum for each direction
    annual_sum = sum(T{:,:}, 1);
    
    % Create new row for annual sum
    annual_row = array2table(annual_sum, 'VariableNames', T.Properties.VariableNames);
    annual_row.Properties.RowNames = {'Annual_Sum (kWh/m^2)'};

    % Append annual sum row to the table
    T = [T; annual_row];

    % Write to Excel
    writetable(T, Excel_filename, 'Sheet', city, 'WriteRowNames', true);
end

fprintf('Saved summary data to: %s\n', Excel_filename);


%% ==== 10. DISPLAY PROCESSING COMPLETION MESSAGE =========================
fprintf('Processing completed. %d files analyzed successfully.\n', min(2, length(csv_files)));
fprintf('All heatmaps and summary saved to: %s\n', Fig_output_dir);
