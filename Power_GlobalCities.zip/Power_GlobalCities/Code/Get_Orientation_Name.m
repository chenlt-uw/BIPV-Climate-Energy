%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script is to get orientation name based on the input facade       %
% surface azimuth angle.                                                 %
% Author: Liutao Chen (chenlt@ust.hk)                                    %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function orientation_name = Get_Orientation_Name(azimuth)
    % Returns the cardinal direction name for a given azimuth angle
    orientation_map = containers.Map(...
        [0, 45, 90, 135, 180, -135, -90, -45], ...
        {'South', 'Southwest', 'West', 'Northwest', 'North', 'Northeast', 'East', 'Southeast'});
    
    if isKey(orientation_map, azimuth)
        orientation_name = orientation_map(azimuth);
    else
        orientation_name = sprintf('%d°', azimuth);
    end
end

