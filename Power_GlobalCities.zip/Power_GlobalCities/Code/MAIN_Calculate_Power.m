%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ========================================================================%
% MAIN SCRIPT FOR BUILDING-INTEGRATED PHOTOVOLTAIC (BIPV) POWER ESTIMATION%
% ========================================================================%
% This script estimates the power generation of BIPV systems on building  %
% facades with different orientations using weather data and solar geometry.
%                                                                         %
% Main Steps:                                                             %
% 1. Extract location information from weather CSV file                   %
% 2. Retrieve solar radiation data for analysis                           %
% 3. Calculate solar geometry for each facade orientation                 %
% 4. Estimate power generation for each orientation                       %
%                                                                         %
% Author: Liutao Chen (chenlt@ust.hk; chenlt@uw.edu)                      %
%                                                                         %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear

%% ==================== Input parameters =============================
% Surface azimuth angles for different facade orientations (degrees)
% Azs: Angle between the normal to the surface and true south
% Westward: positive, Eastward: negative
% 0 for south-facing orientation, 180 for north-facing
% S, SW, W, NW, N, NE, E, SE:
AzsSet = [0, 45, 90, 135, 180, -135, -90, -45];  % 8 cardinal directions

% reference conversion efficiency at Standard test condition (-/°C)
eta_ref = 0.12;

% Directory paths
weather_data_dir = '../Weather_Data/';
power_output_dir = '../Power_Output/';

% Create output directory if it doesn't exist
if ~exist(power_output_dir, 'dir')
    mkdir(power_output_dir);
    fprintf('Created output directory: %s\n', power_output_dir);
end


%% ==================== 0. FIND ALL CSV FILES =============================
fprintf('=== MULTI-CITY BIPV POWER ESTIMATION ===\n');
fprintf('Searching for weather data files in: %s\n', weather_data_dir);

% Get all CSV files in the directory
csv_files = dir(fullfile(weather_data_dir, '*.csv'));

if isempty(csv_files)
    error('No CSV files found in directory: %s', weather_data_dir);
end

fprintf('Found %d CSV files to process:\n', length(csv_files));
for i = 1:length(csv_files)
    fprintf('  %d. %s\n', i, csv_files(i).name);
end
fprintf('\n');


%% ==================== 1. PROCESS EACH CITY FILE =========================
% Initialize structure to store all results
city_results = struct();

for file_idx = 1:length(csv_files)
    filename = fullfile(weather_data_dir, csv_files(file_idx).name);

    fprintf('Processing file %d of %d: %s\n', file_idx, length(csv_files), csv_files(file_idx).name);
    fprintf('============================================\n');

    % Extract city name from file path
    [~, name, ~] = fileparts(filename);
    city_name = upper(name);
    city_name = strrep(city_name, '_', ' ');

    fprintf('City: %s\n', city_name);


    %% ==================== 2. EXTRACT LOCATION INFORMATION ===================
    try
        % Extract latitude, longitude, and time zone
        [Lat, Lon, TimeZone] = Extract_Location_Info(filename);
        fprintf('Location: Latitude = %.2f°, Longitude = %.2f°, TimeZone = %.1f\n', Lat, Lon, TimeZone);
    catch ME
        warning('Failed to extract location info for %s: %s', city_name, ME.message);
        continue; % Skip to next file
    end


    %% ==================== 3. FIND DATA STARTING LINE ========================
    % Find the starting line of the actual weather data table
    data_start_line = Find_Data_StartLine(filename);
    fprintf('Weather data starts at line: %d\n', data_start_line);


    %% ==================== 4. READ WEATHER DATA TABLE =======================
    % Read the main data table, skipping metadata headers
    weather_data = readtable(filename, 'HeaderLines', data_start_line-1);

    % Display table information
    fprintf('Table Size: %d rows × %d columns\n', size(weather_data, 1), size(weather_data, 2));


    %% ==================== 5. EXTRACT SOLAR RADIATION DATA ===================
    % Extract radiation data
    [SW_data, column_info] = Extract_Radiation_Data(weather_data);
    fprintf('Radiation data columns found:\n');
    fprintf('  Direct: %s (Column %d)\n', column_info.direct_name, column_info.direct_idx);
    fprintf('  Diffuse: %s (Column %d)\n', column_info.diffuse_name, column_info.diffuse_idx);


    %% ==================== 7. CALCULATE POWER FOR EACH FACADE ORIENTATION ====
    fprintf('\n=== CALCULATING POWER GENERATION ===\n');
    fprintf('Analyzing %d facade orientations...\n', length(AzsSet));

    % Initialize power output matrix: 8760 hours × 8 orientations
    PowerSum = zeros(8760, length(AzsSet));
    orientation_names = cell(1, length(AzsSet));

    % Create datetime array for the entire year (assuming 2023 as reference year)
    start_date = datetime(2023, 1, 1, 0, 0, 0);
    end_date = datetime(2023, 12, 31, 23, 0, 0);
    time_vector = (start_date:hours(1):end_date)';


    for i = 1:length(AzsSet)
        Azs = AzsSet(i);

        % Get orientation name for reporting
        orientation_name = Get_Orientation_Name(Azs);
        orientation_names{i} = orientation_name;
        fprintf('  Processing %s facade (Azimuth: %d°)...\n', orientation_name, Azs);


        %% ==================== 7.1 CALCULATE SOLAR GEOMETRY===================
        % Calculate solar angles for the entire year (365 days × 24 hours)
        % Initialization
        nd = 365;
        zenith = zeros(24,nd);   % zenith: Solar zenith angle in radians (0° at zenith, 90° at horizon)
        azimuth = zeros(24,nd);  % azimuth: Solar azimuth angle in radians (0° at north, clockwise)
        incd = zeros(24,nd);     % incd: Incident angle on surface in radians (0° normal)
        kounter = 1;

        for iday = 1:nd
            [zenith(:,kounter),azimuth(:,kounter),incd(:,kounter)] = ...
                Calculate_Zenith_Azimuth_Incidence(Lat, Lon, Azs, iday, TimeZone);

            % 1 E,SE,S,SW; 2 W,NW,N,NE
            kounter=kounter+1;
        end

        zenith = zenith(:); azimuth = azimuth(:); incd = incd(:);
        Incd_Ang = incd(:)*180/pi;   % Radians -> degree


        %% ==================== 7.2 CALCULATE GLASS TRANSMITTANCE =============
        % For semi-tranparent BIPV, there is a glass layer in front of solar cells,
        % Solar radiation will transmit the glass to reach on the solar cells
        % We calculate the transmittance for direct and diffuse radiation.
        % The transmittance through the cover for diffuse radiation is assumed equal to the cover transmittance
        % for beam radiation at an incidence angle of 60 degree. % https://core.ac.uk/download/pdf/82500266.pdf
        Eff_Angle = 60;  % [26] Howell JR. The Monte Carlo Method in Radiative Heat Transfer, Journal of Heat Transfer 1998; 120(3): 547-60
        trans0 = 0.784;  % Transmittance when angle = 0 ;
        X_trans = 1.688; % Parameter related to glass refraction;

        % Glass transmittance
        valid_angles = Incd_Ang < 89; % Avoid angles near 90° where tan → ∞
        trans_Glass = zeros(size(Incd_Ang));
        trans_Glass(valid_angles) = trans0 .* (1 - (tand(Incd_Ang(valid_angles)/2)).^X_trans);
        trans_Glass(~valid_angles) = 0;     % No transmission at grazing angles
        trans_Eff = trans0*(1-(tand(Eff_Angle/2)).^X_trans);      % Effective transmittance for diffuse


        %% ==================== 7.3 CALCULATE INCIDENCE ANGLE MODIFIER ========
        % Incidence angle modifier (-), accounting for the influence of incident angle on the power output.
        IAM = 1 - (1.098*1e-4).*Incd_Ang - (6.267*1e-6).*Incd_Ang.^2 + ...
            (6.583*1e-7).*Incd_Ang.^3 - (1.4272*1e-8).*Incd_Ang.^4;
        IAM_Eff = 1 - (1.098*1e-4).*Eff_Angle - (6.267*1e-6).*Eff_Angle.^2 + ...
            (6.583*1e-7).*Eff_Angle.^3 - (1.4272*1e-8).*Eff_Angle.^4;


        %% ==================== 7.4 CALCULATE RADIATION ON FACADE =============
        % Determine sunlit conditions (facade receives direct radiation)
        is_sunlit = (incd < pi/2) & (zenith < pi/2);

        % Radiation component on vertical facade, assuming there are no walls around 
        BIPV_Direct = SW_data(:,1) .* cos(incd) .* is_sunlit;  % Direct radiation component
        BIPV_Diffuse = SW_data(:,2) * 0.5;                     % Diffuse radiation: View factor = 0.5(1-FWW) https://rmets.onlinelibrary.wiley.com/doi/full/10.1002/qj.2032
        % Total_SW_BIPV = BIPV_Direct + BIPV_Diffuse;          % In UCM, we further consider the reflection from ground and wall


        %% ==================== 7.5 CALCULATE POWER GENERATION ================
        % Power calculation considering:
        % - Direct radiation with angle-dependent transmittance and IAM
        % - Diffuse radiation with effective values

        % Note:
        % UCM and UBEM calculate cell temperature TPV based on energy balance,
        % and use equation to estimate actural efficiency:
        % eta_ref*(1-beta_ref*(TPV - 25));  % beta_ref is temperature coefficient.
        % But temperature effects on efficiency are neglected in this simplified code.

        Power = BIPV_Direct .* eta_ref .* trans_Glass .* IAM + ...
            BIPV_Diffuse .* eta_ref .* trans_Eff .* IAM_Eff;           % Instance Power of PV panel (W/m^2)

        % Convert unit and store results
        PowerSum(:,i) = Power*1;   % Unit: Wh/m^2

        fprintf('    %s facade: Total power = %.2f kWh/m²/year\n', ...
            orientation_name, sum(PowerSum(:,i))/1000);

    end

    %% ==================== 8. CREATE POWER TABLE WITH TIMESTAMP ==============
    % Create table with timestamp and power data for each orientation
    Power_table = table(time_vector, 'VariableNames', {'DateTime | Power (Wh/m^2)'});

    % Add power data for each orientation
    for i = 1:length(orientation_names)
        col_name = orientation_names{i};
        col_name = matlab.lang.makeValidName(col_name);
        Power_table.(col_name) = PowerSum(:, i);
    end

    %% ==================== 9. STORE RESULTS ==============================
    % Save results for this city
    city_results(file_idx).city_name = city_name;
    city_results(file_idx).filename = csv_files(file_idx).name;
    city_results(file_idx).latitude = Lat;
    city_results(file_idx).longitude = Lon;
    city_results(file_idx).timezone = TimeZone;
    city_results(file_idx).PowerSum = PowerSum;
    city_results(file_idx).orientation_names = orientation_names;
    city_results(file_idx).orientations = AzsSet;
    city_results(file_idx).PowerTable = Power_table;

    %% ==================== 10. SAVE INDIVIDUAL CITY RESULTS ==============
    % output_filename = fullfile(power_output_dir, sprintf('%s_Power.mat', name));
    % save(output_filename, 'PowerSum', 'Power_table', 'AzsSet', 'orientation_names', ...
    %     'Lat', 'Lon', 'TimeZone', 'city_name');

    % Save in Csv format
    csv_output_filename = fullfile(power_output_dir, sprintf('%s_Power.csv', name));
    writetable(Power_table, csv_output_filename);

    fprintf('Results saved to:\n');
    % fprintf('  MAT file: %s\n', output_filename);
    fprintf('  CSV file: %s\n', csv_output_filename);
    fprintf('============================================\n\n');

end




