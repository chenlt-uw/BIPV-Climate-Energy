**Building-integrated Photovoltaic (BIPV) Power Estimation for Different Facade Orientations**

This folder estimates the hourly power output for BIPV facades with different orientations using Typical Meteorological Year (TMY) weather data.

Author: Liutao Chen (chenlt@ust.hk; chenlt@uw.edu)



**Project Structure**

Project Root/

│

├── Weather\_Data/              # Weather data directory

│   ├── EPW/                   # Original TMY weather files in EPW format

│   └── \[Converted CSV files]  # Weather files converted to CSV format

│

├── Code/                      # MATLAB code directory

│   ├── MAIN\_Calculate\_Power.m # Main script for power calculation

│   └── Visualize\_allCities.m  # Visualization script

│

├── Power\_Output/              # Generated power output data (CSV format)

└── Power\_Month\_HeatMap/       # Generated heatmap visualizations





**Prerequisites**

* MATLAB
* EnergyPlus (for weather file conversion)
* TMY weather data files (.epw format)





**Setup Instructions**

1. **Weather Data Preparation**

i) Download TMY weather files from https://energyplus.net/weather and save them in: Weather\_Data/EPW/



ii) Use EnergyPlus "Weather Statistics and Conversions" tool to convert EPW files to CSV format:

* Input: Weather\_Data/EPW/\[city\_name].epw
* Output: Weather\_Data/\[city\_name].csv



iii) Repeat Step 2 for each city you want to simulate.





**2. Power Calculation**

i) Navigate to the Code folder and run the main calculation script: MAIN\_Calculate\_Power.m



ii) This script will:

* Process weather data for all cities
* Calculate PV power output for different facade orientations
* Generate hourly power data (8760 hours) for each city
* Save results as CSV files in Power\_Output/ folder





**3. Visualization**

i) Run the visualization script: Visualize\_allCities.m

ii) This script will:

* Process the hourly power output data
* Generate monthly heatmap visualizations
* Save heatmaps in Power\_Month\_HeatMap/ folder





**Output Files**

**Power Output Data**

* Location: Power\_Output/
* Format: CSV files
* Content: Hourly BIPV power output (kW) for different facade orientations
* Temporal resolution: 8760 hours (one year)





**Visualization Output**

* Location: Power\_Month\_HeatMap/
* Format: Image files (heatmaps)
* Content: Monthly power generation heatmaps for each city





**Adding New Cities**

To simulate new cities:

i) Download TMY data for the new city

ii) Follow the weather data preparation steps

iii) Run MAIN\_Calculate\_Power.m and Visualize\_allCities.m again





**Notes**

* Ensure all file paths are correctly set in the MATLAB scripts
* Appropriate simplifications have been applied to the power estimation code compared to the BIPV module in BEM-SLUM and GeoBEM approaches.
* For questions or issues regarding this code, please check the file paths and ensure all prerequisite software is properly installed.
