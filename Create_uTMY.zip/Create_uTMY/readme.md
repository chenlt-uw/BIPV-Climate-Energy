**uTMY Generator: Urbanized Typical Meteorological Year EPW File Creator**



**Overview**

This MATLAB tool generates urbanized Typical Meteorological Year (uTMY) EPW files by integrating the Urban Canopy Model (UCM) outputs with standard meteorological data. It replaces default air temperature, humidity, and wind speed values with urban canyon equivalents to better represent urban microclimate conditions. The generated uTMY file maintains full compatibility with EnergyPlus building simulation software



Author: Liutao Chen (chenlt@ust.hk; chenlt@uw.edu)



**File Structure**

Project\_root/

├── CreateEPW.m                 # Main script to generate uTMY files

├── formatEPWValue.m            # Helper function for EPW data formatting

├── TMY.epw                     # Base Typical Meteorological Year file

├── readme.txt                  # This documentation file

├── UCM\_Output\_Samples/         # Folder containing UCM simulation outputs

│   ├── Sample\_UCM\_Scenario1\_id1.mat

│   └── \[Other UCM output files...]

└── uTMY/                       # Output folder for generated uTMY files

    ├── uTMY\_Sample\_UCM\_Scenario1\_id1.epw

    └── \[Other generated uTMY files...]



**Prerequisites**

* MATLAB
* Base TMY EPW file (provided as TMY.epw)
* UCM output files (stored in UCM\_Output\_Samples folder)



**Usage Instructions**

1. Place UCM output .mat files in the UCM\_Output\_Samples folder
2. Execute the main script in MATLAB: CreateEPW.m

3\. Generated uTMY EPW files will be saved in the uTMY folder



