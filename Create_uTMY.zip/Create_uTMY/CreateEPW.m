%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% uTMY Generator: Urbanized Typical Meteorological Year EPW File Creator
% -------------------------------------------------------------------------
% Description:
% This script generates urbanized Typical Meteorological Year (uTMY) EPW
% files by integrating coupled Urban Canopy Model (UCM) outputs with
% standard meteorological data. It replaces default temperature, humidity,
% and wind speed values with average canyon air temperature, relative
% humidity, and wind speed to better represent urban microclimate
% conditions for building energy simulations and urban climate studies.
%
% Methodology:
% 1. Reads base TMY EPW file containing standard meteorological data
% 2. Loads UCM output data for different simulation scenarios
% 3. Replaces dry bulb temperature, relative humidity, and wind speed
%    with urban canyon values from UCM simulations
% 4. Generates new uTMY EPW file
%
% Key Features:
% - Maintains EPW file format compatibility with building simulation software
% - Preserves all original meteorological parameters except modified ones
%
% Author: Liutao Chen (chenlt@ust.hk; chenlt@uw.edu)
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear

%% Read Base EPW Meteorological File
% --------------------------------------------------------------------
% This section reads the standard Typical Meteorological Year (TMY) file
filename = 'TMY.epw';             % Input EPW file name
fid = fopen(filename, 'r');       % Open file for reading
if fid == -1
    error('Cannot open default EPW file. Please check file existence and path.');
end

% Read EPW file header (first 8 lines containing metadata)
header = textscan(fid, '%s', 8, 'Delimiter', '\n');
header = header{1};


%% Read Meteorological Data Section
% --------------------------------------------------------------------
% EPW files contain 35 columns of hourly meteorological data for full year
% Column definitions based on EnergyPlus EPW format specification
numCols = 35;  % Standard EPW file has 35 columns of meteorological data
TMY_data = textscan(fid, repmat('%s', 1, numCols), 'Delimiter', ',');
fclose(fid);  % Close file after reading

% Initialize uTMY structure with original data
uTMY = TMY_data;


%% Load UCM Output Files
% --------------------------------------------------------------------
% Load UCM simulation results containing urban canyon modifications for
% air temperature, humidity, and wind speed
% Get all .mat files from UCM_Output_Samples folder
UCM_folder = 'UCM_Output_Samples';
mat_files = dir(fullfile(UCM_folder, '*.mat'));

% Check if any mat files exist
if isempty(mat_files)
    warning('No .mat files found in %s folder. Please check the folder path and files.', UCM_folder);
    return;
end

fprintf('Found %d UCM output files. Processing...\n', length(mat_files));


%% Process each UCM output file
for file_idx = 1:length(mat_files)

    % Get current filename
    current_filename = mat_files(file_idx).name;
    UCM_output_Filename = fullfile(UCM_folder, current_filename);

    fprintf('Processing file %d/%d: %s\n', file_idx, length(mat_files), current_filename);

    % Load UCM simulation results
    try
        Output_sample = load(UCM_output_Filename);

        % Check if UCM_output field exists
        if ~isfield(Output_sample, 'UCM_output')
            warning('File %s does not contain UCM_output field. Skipping.', current_filename);
            continue;
        end

        UCM_output = Output_sample.UCM_output;  % Extract UCM output structure
        [numRows, numCols] = size(UCM_output);


        %% Replace Meteorological Parameters with Urban Values
        uTMY{7} = num2cell(UCM_output.Tcan);   % Replace dry bulb temperature
        uTMY{9} = num2cell(UCM_output.RHcan);  % Replace relative humidity
        uTMY{22} = num2cell(UCM_output.Ucan);  % Replace wind speed

        %% Generate Output uTMY EPW File
        % Create new EPW file with urban-modified meteorological data while
        % preserving original file structure and unmodified parameters
        % Create output filename by adding 'uTMY_' prefix
        [~, name_only, ~] = fileparts(current_filename);
        outputFilename = sprintf('uTMY\\uTMY_%s.epw', name_only);

        % Create uTMY folder if it doesn't exist
        if ~exist('uTMY', 'dir')
            mkdir('uTMY');
        end

        % Open output file for writing
        fid = fopen(outputFilename, 'w');
        if fid == -1
            warning('Cannot create output EPW file %s. Check directory permissions.', outputFilename);
            continue;
        end

        % Write EPW header (metadata preserved from original)
        for i = 1:length(header)
            fprintf(fid, '%s\n', header{i});
        end

        % Write modified meteorological data section
        for i = 1:numRows
            for j = 1:size(uTMY,2)
                % Format and write each data value with proper comma separation
                if j == size(uTMY,2)
                    fprintf(fid, '%s\n', formatEPWValue(uTMY{j}{i}, j));
                else
                    fprintf(fid, '%s,', formatEPWValue(uTMY{j}{i}, j));
                end
            end
        end

        fclose(fid);  % Close output file
        fprintf('Successfully created uTMY EPW file: %s\n', outputFilename);
    catch ME
        warning('Error processing file %s: %s', current_filename, ME.message);
        continue;
    end
end

fprintf('Completed processing all files. Total processed: %d/%d\n', file_idx, length(mat_files));


